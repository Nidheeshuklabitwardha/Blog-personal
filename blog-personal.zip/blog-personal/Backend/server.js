const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// In-memory data storage
let posts = [];
let currentId = 1;

// REST API Endpoints

// Get all posts
app.get('/api/posts', (req, res) => {
  res.json(posts);
});

// Get a single post by ID
app.get('/api/posts/:id', (req, res) => {
  const post = posts.find((p) => p.id === parseInt(req.params.id, 10));
  if (post) {
    res.json(post);
  } else {
    res.status(404).send({ message: 'Post not found' });
  }
});

// Create a new post
app.post('/api/posts', (req, res) => {
  const { title, content } = req.body;
  const newPost = { id: currentId++, title, content };
  posts.push(newPost);
  res.status(201).json(newPost);
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
