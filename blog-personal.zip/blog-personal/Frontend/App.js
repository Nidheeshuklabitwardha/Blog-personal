import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import BlogPostDetails from './pages/BlogPostDetails';

const App = () => (
  <>
    <Navbar />
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/posts/:id" element={<BlogPostDetails />} />
    </Routes>
  </>
);

export default App;
