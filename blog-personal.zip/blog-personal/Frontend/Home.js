import React from 'react';
import BlogPostList from '../components/BlogPostList';
import BlogPostForm from '../components/BlogPostForm';

const Home = () => (
  <div>
    <h1>Blog Posts</h1>
    <BlogPostForm />
    <BlogPostList />
  </div>
);

export default Home;
